필요 설정 :
자바 버전 8 이상
크롤링 기능 실행을 위해서 jsoup.jar 파일 설정이 필요합니다.

설정 및 실행 방법 :
1. 1조 CIMS.zip과 1조 CIMS 실행에 필요한 jar 파일.zip을 압축 해제합니다.
2. eclipse 실행 후 file 메뉴 창에서 import - Existing projects into Workspace 선택 후 NEXT 클릭합니다.
3. Select root directory에서 압축 해제한 CIMS폴더를 지정 후 Finish를 누릅니다.
4. CIMS project 창에서 마우스 우클릭 - properties - java build path - Libraries - Add External JARs 선택합니다.
5. 압축 해제한 jar 파일을 모두 추가한다. 추가 후 'Apply and Close' 선택합니다.
6. eclipse에서 src -> (default package)에 위치한 main_vaccine.java를 실행시킵니다.

※ 경우에 따라 이클립스 코드 상에서 한글이 깨져보일 수 있으나, 실행 시에는 문제가 없습니다.